<?php

class Conexion{
    private $host = "localhost";
    private $usuario = "root";
    private $contrasena = "";
    private $db = "notas";
    private $conect;

    public function conectar()
    {
        try {
            $connectionString = "mysql:host=" . $this->host . ";dbname=" . $this->db . ";charset=utf8";
            $con = $this->conect = new PDO($connectionString, $this->usuario, $this->contrasena);
            $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            //echo "conectado";
            return $con;
        } catch (PDOException $e) {
            $this->conect = "Error en Conexion";
            echo "ERROR: " . $e->getMessage();
        }
    }
}

