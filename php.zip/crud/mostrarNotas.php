<?php
require_once("usuario/Usuario.php");

$obj = new Usuario();

$json = $obj->mostrarNotas();
$jsonEstring = json_encode($json);

echo $jsonEstring;
