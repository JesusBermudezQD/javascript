<?php
require_once("configuracion/Conexion.php");
class Usuario extends Conexion
{
    private $strTitulo;
    private $strDescripcion;

    public function mostrarNotas()
    {
        $sql = 'SELECT * FROM nota';
        $mostrar = Conexion::conectar()->prepare($sql);
        $mostrar->execute();
        return $mostrar->fetchAll();
    }

    public function insertarNota(string $titulo,string $descripcion){
        $this->strTitulo=$titulo;
        $this->strDescripcion=$descripcion;

        $sql='INSERT INTO nota(titulo,descripcion) VALUES (?,?)';
        $agregar=Conexion::conectar()->prepare($sql);
        $arrayData=array($this->strTitulo,$this->strDescripcion);
        return $agregar->execute($arrayData);
    }

    public function obtenerNota(int $id)
    {
        $sql = 'SELECT * FROM nota WHERE id=?';
        $mostrar = Conexion::conectar()->prepare($sql);
        $mostrar->execute(array($id));
        return $mostrar->fetch();
    }

    public function actualizarNota(int $id,string $titulo,string $descripcion)
    {
        $this->strTitulo=$titulo;
        $this->strDescripcion=$descripcion;

        $sql='UPDATE nota SET titulo=?,descripcion=? WHERE id=?';
        $editar=Conexion::conectar()->prepare($sql);
        $arrayData=array($this->strTitulo,$this->strDescripcion,$id);
        return $editar->execute($arrayData);
    }

    public function eliminarNota(int $id)
    {
        $sql='DELETE FROM `nota` WHERE `nota`.`id` = ?';
        $eliminar=Conexion::conectar()->prepare($sql);
        return $eliminar->execute(array($id));

    }
}
