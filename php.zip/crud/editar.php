<?php

require_once("usuario/Usuario.php");
$id = $_POST["id"];
$titulo = $_POST["titulo"];
$des = $_POST["descripcion"];


$obj = new Usuario();
$obj->actualizarNota($id, $titulo, $des);

echo "Nota Actualizada";
