<!-- Modal -->
<div class="modal fade" id="botonEdit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Editar Nota</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form id="form1">
                    <div class="form-group" id="aquiModal">
                        <label for="exampleFormControlInput1">Titulo:</label>
                        <input type="text" class="form-control" id="tituloEdit" name="titulo">
                        <input type="hidden" class="form-control" id="idEdit">
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Descripcion:</label>
                        <textarea class="form-control" id="descripcionEdit" name="descripcion" rows="3"></textarea>
                    </div>

                    <div class="modal-footer">

                        <button type="button" onclick="editar()" class="btn btn-block btn-primary">Save changes</button>
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>