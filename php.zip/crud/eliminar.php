<?php
require_once("usuario/Usuario.php");

$id = $_POST["id"];

$obj = new Usuario();

$obj->eliminarNota($id);

echo "Nota Eliminada";
