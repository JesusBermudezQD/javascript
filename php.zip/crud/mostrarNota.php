<?php
include_once("usuario/Usuario.php");

$obj = new Usuario();

$id = $_GET["id"];

$json = $obj->obtenerNota($id);
$jsonEstring = json_encode($json);

echo $jsonEstring;
