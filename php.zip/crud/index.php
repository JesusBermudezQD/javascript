<?php include_once("componentes/parte1.php") ?>

<div class="container mb-5">
    <h1 class="text-center text-white mt-5">CRUD NOTAS</h1>

    <div class="row bg-light ">
        <div class="col-md-3">
            <div class="m-3">

                <form id="form">
                    <h4 class="text-center mt-5 mb-3" id="agre">Agregar Nota</h4>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Titulo:</label>
                        <input type="text" class="form-control" id="titulo" name="titulo">
                    </div>

                    <div class="form-group">
                        <label for="exampleFormControlTextarea1">Descripcion:</label>
                        <textarea class="form-control" id="descripcion" name="descripcion" rows="3"></textarea>
                    </div>

                    <button class="btn btn-info btn-block">Agregar</button>
                </form>
            </div>
        </div>
        <div class="col-md-9 mb-5 pr-5">
            <h4 class="text-center mt-5">Notas</h4>
            <hr>
            <div class="card-columns" id="lista"></div>
        </div>
    </div>
</div>

<?php include_once("componentes/modalEditar.php") ?>

<script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>
<script type="text/javascript">
    document.addEventListener("DOMContentLoaded", () => {
        mostrar();
    });
    document.getElementById("form").addEventListener("submit", (e) => {
        e.preventDefault();
        insertar();
        mostrar();
    });

    function insertar() {
        let titulo = document.getElementById("titulo").value;
        let des = document.getElementById("descripcion").value;
        const agre = document.getElementById("agre");

        if (titulo === "" || des === "") {
            const div = document.createElement("div");
            div.classList.add("alert", "alert-danger", "text-center");
            div.innerText = "Complete los Campos";
            document.getElementById("form").insertBefore(div, agre);

            setTimeout(() => {
                document.getElementById("titulo").value = "";
                document.getElementById("descripcion").value = "";
                div.remove();
            }, 2000);
        } else {
            const url = "insertar.php";
            const data = "titulo=" + titulo + "&descripcion=" + des;
            $.ajax({
                type: 'POST',
                url: url,
                data: data
            }).done(function(res) {
                mostrar();
                const div = document.createElement("div");
                div.classList.add("alert", "alert-primary", "text-center");
                div.innerText = res;
                document.getElementById("form").insertBefore(div, agre);

                setTimeout(() => {
                    document.getElementById("titulo").value = "";
                    document.getElementById("descripcion").value = "";
                    div.remove();
                }, 2000);
            });
        }
    }

    function mostrar() {
        const url = "mostrarNotas.php";

        $.ajax({
            type: 'GET',
            url: url
        }).done(function(res) {
            let notas = JSON.parse(res);

            let card = '';
            notas.forEach(nota => {
                card += `
                <div class="card ">
                    <div class="card-body">
                        <h5 class="card-title">${nota.titulo}</h5>
                        <p class="card-text">${nota.descripcion} </p>
                        <input type="hidden" value="${nota.id}">
                        <a onclick="botonEdit(${nota.id})" class="btn btn-warning" data-toggle="modal" data-target="#botonEdit">Editar</a>
                        <a onclick="eliminar(${nota.id})" class="btn btn-danger">Eliminar</a>
                    </div>
                </div>
                `;

            });

            cardColumns = document.getElementById("lista").innerHTML = card;

        });
    }

    function eliminar(id) {
        const url = "eliminar.php";
        const data = "id=" + id;
        $.ajax({
            type: 'POST',
            url: url,
            data: data
        }).done(function(res) {
            const div = document.createElement("div");
            div.classList.add("alert", "alert-warning", "text-center");
            div.innerText = res;
            document.getElementById("form").insertBefore(div, agre);

            setTimeout(() => {
                div.remove();
            }, 2000);

            mostrar();
        });

    }

    function botonEdit(id) {
        const tituloEdit = document.getElementById("tituloEdit");
        const desEdit = document.getElementById("descripcionEdit");
        const idEdit = document.getElementById("idEdit");

        const url = "mostrarNota.php";
        const data = "id=" + id;
        $.ajax({
            type: 'GET',
            url: url,
            data: data
        }).done(function(res) {
            let nota = JSON.parse(res);
            tituloEdit.value = nota.titulo;
            desEdit.value = nota.descripcion;
            idEdit.value = nota.id;
        });
    }


    function editar() {
        const tituloEdit = document.getElementById("tituloEdit").value;
        const desEdit = document.getElementById("descripcionEdit").value;
        const idEdit = document.getElementById("idEdit").value;

        const tituloModal = document.getElementById("aquiModal");

        if (tituloEdit === "" || desEdit === "" || idEdit === "") {
            const div = document.createElement("div");
            div.classList.add("alert", "alert-danger", "text-center");
            div.innerText = "Complete los Campos";
            document.getElementById("form1").insertBefore(div, tituloModal);

            setTimeout(() => {
                tituloEdit.value = "";
                desEdit.value = "";
                div.remove();
            }, 2000);
        } else {
            const url = "editar.php";
            const data = "id=" + idEdit + "&titulo=" + tituloEdit + "&descripcion=" + desEdit;
            $.ajax({
                type: 'POST',
                url: url,
                data: data
            }).done(function(res) {
                mostrar();
                const div = document.createElement("div");
                div.classList.add("alert", "alert-success", "text-center");
                div.innerText = res;
                document.getElementById("form1").insertBefore(div, tituloModal);

                setTimeout(() => {
                    document.getElementById("tituloEdit").value = "";
                    document.getElementById("descripcionEdit").value = "";
                    div.remove();
                }, 2000);
            });
        }
    }
</script>

<?php include_once("componentes/parte2.php") ?>