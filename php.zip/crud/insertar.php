<?php
require_once("usuario/Usuario.php");
$titulo = $_POST["titulo"];
$des = $_POST["descripcion"];

$obj = new Usuario();
$obj->insertarNota($titulo, $des);
echo "Nota Agregada";
