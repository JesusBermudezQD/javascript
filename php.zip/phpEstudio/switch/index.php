<?php

$eleccion = "a";

switch ($eleccion) {
    case 'pizza':
        echo "usted escogio $eleccion";
        break;
    case 'carne':
        echo "usted escogio $eleccion";
        break;
    case 'pollo':
        echo "usted escogio $eleccion";
        break;
    default:
        echo "opcion no valida";
        break;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <h1>Ingresa una opcion:</h1>
    <hr>
    <h2>1) pizza</h2>
    <h2>2) carne</h2>
    <h2>3) pollo</h2>
</body>

</html>