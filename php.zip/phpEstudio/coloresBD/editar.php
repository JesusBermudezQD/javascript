<?php
//editar.php?id=1&color=success&descripcion=ahora eres verde perro
$id = $_GET['id'];
$color = $_GET['color'];
$descripcion = $_GET['descripcion'];

include_once 'conexion.php';

$sql_editar = 'UPDATE colores SET color=?,descripcion=? WHERE id=?';
$sentencia_editar = $mbd->prepare($sql_editar);
$sentencia_editar->execute(array($color, $descripcion, $id));

header('location:index.php');

$sentencia_editar = null;
$mbd = null;
