<?php

$link = 'mysql:host=localhost;dbname=colores';
$usuario = 'root';
$contrasena = '';

try {
    $mbd = new PDO($link, $usuario, $contrasena);
    echo "conectado <br>";
    /* foreach ($mbd->query('SELECT * from `colores`') as $fila) {
        print_r($fila);
    }
    $mbd = null; */
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
