<?php
include_once 'conexion.php';

//LEER
$sql_leer = 'SELECT * FROM colores';
$gsent = $mbd->prepare($sql_leer);
$gsent->execute();
$resultado = $gsent->fetchAll();
/* var_dump($resultado); */

//AGREGAR

if ($_POST) {
    $color = $_POST['color'];
    $descripcion = $_POST['descripcion'];

    $sql_agregar = 'INSERT INTO colores(color,descripcion) VALUES (?,?)';
    $sentencia_agregar = $mbd->prepare($sql_agregar);
    $sentencia_agregar->execute(array($color, $descripcion));
    header('location:index.php');

    $sentencia_agregar = null;
    $mbd = null;
}

if ($_GET) {
    $id = $_GET['id'];
    $sql_unico = 'SELECT * FROM colores WHERE id=?';
    $gsent_unico = $mbd->prepare($sql_unico);
    $gsent_unico->execute(array($id));
    $resultado_unico = $gsent_unico->fetch();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewpo/rt" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <title>Document</title>
</head>

<body class="bg-info">

    <div class="container mt-5 bg-light">
        <div class="row">
            <div class="col mt-5 mb-5">

                <?php foreach ($resultado as $data) : ?>
                    <div class='alert alert-<?php echo $data['color'] ?>' role="alert">
                        <?php echo $data['color'] ?> -
                        <?php echo $data['descripcion'] ?>

                        <a href="eliminar.php?id=<?php echo $data['id'] ?>" class="float-right text-decoration-none">
                            <i class="material-icons">
                                delete
                            </i>
                        </a>

                        <a href="index.php?id=<?php echo $data['id'] ?>" class="float-right text-decoration-none">
                            <i class="material-icons">
                                edit
                            </i>
                        </a>



                    </div>
                <?php endforeach ?>
            </div>
            <div class="col">
                <!-- Formulario Agregar -->
                <?php if (!$_GET) : ?>
                    <form method="POST" class="mt-5 mb-5">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Crear alert:</label>
                            <input type="text" class="form-control mb-3" name="color" placeholder="Ej: danger">
                            <label for="exampleInputEmail1">Agregar descripcion:</label>
                            <input type="text" class="form-control" name="descripcion">
                        </div>
                        <button class="btn btn-primary btn-block">Agregar</button>
                    </form>
                <?php endif ?>
                <!-- Formulario Editar -->
                <?php if ($_GET) : ?>
                    <form method="GET" action="editar.php" class="mt-5 mb-5">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Editar alert:</label>
                            <input type="text" class="form-control mb-3" name="color" value="<?php echo $resultado_unico['color'] ?>">
                            <label for="exampleInputEmail1">Editar descripcion:</label>
                            <input type="text" class="form-control" name="descripcion" value="<?php echo $resultado_unico['descripcion'] ?>">
                            <input type="hidden" name="id" value="<?php echo $resultado_unico['id'] ?>">
                        </div>
                        <button class="btn btn-primary btn-block">Agregar</button>
                    </form>
                <?php endif ?>
            </div>
        </div>
    </div>
</body>

</html>

<?php
$gsent = null;
$mbd = null;
?>