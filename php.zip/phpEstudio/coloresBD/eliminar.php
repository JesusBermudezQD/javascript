<?php
$id = $_GET['id'];

include_once 'conexion.php';

$sql_eliminar = 'DELETE FROM `colores` WHERE `colores`.`id` = ?';
$sentencia_eliminar = $mbd->prepare($sql_eliminar);
$sentencia_eliminar->execute(array($id));

header('location:index.php');

$sentencia_eliminar = null;
$mbd = null;
