<?php include("nav.php") ?>
<nav class="navbar navbar-light bg-info">
    <a class="navbar-brand" href="#">
        <img src="/docs/4.5/assets/brand/bootstrap-solid.svg" width="30" height="30" class="d-inline-block align-top" alt="" loading="lazy">
        Bootstrap
    </a>
</nav>

<div class="container">
    <div class="row">
        <div class="col bg-success">Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptatibus vel perferendis magni assumenda aliquid? Tenetur neque est perspiciatis dignissimos iusto provident delectus iste quisquam excepturi hic labore nostrum, minima magni.</div>
        <div class="col bg-danger">Lorem ipsum dolor sit amet consectetur adipisicing elit. Veritatis vel eius libero sint rerum labore officiis nostrum qui nemo eum? Incidunt eum saepe, modi animi fugit quidem dicta eius consequuntur!</div>
    </div>
</div>



<?php include("footer.php") ?>