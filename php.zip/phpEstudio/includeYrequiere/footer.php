    <footer class="bg-secondary text-white">
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Sunt sapiente amet quo. A nesciunt possimus recusandae delectus maiores sequi et fuga. Iusto minus earum reprehenderit et nemo facere temporibus quia.
    </footer>

    </body>

    </html>