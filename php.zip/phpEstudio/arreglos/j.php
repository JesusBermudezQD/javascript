<?php

//arreglos normales
/* $animales = ["Perro", "gato", "morrocolla"]; */
/* <?php
$con = 1;
foreach ($animales as $i => $animal) {
    echo '<li>la mascota #' . $con . ' es un $animal</li>';
    $con++;
}
?> */

//arreglos asociativos

$razas[0] = [
    'nombre' => 'roky'

];
$razas[1] = [
    'nombre' => 'michu'
];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php

    foreach ($razas as $animal) {
        echo '<li>El animal ' . $animal['nombre'] . ' es chevere</li>';
    }

    ?>

</body>

</html>