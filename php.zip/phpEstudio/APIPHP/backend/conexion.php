<?php

$link = 'mysql:host=localhost;dbname=api';
$usuario = 'root';
$contrasena = '';
try {
    $mbd = new PDO($link, $usuario, $contrasena);

    /* echo 'conectado </br>'; */
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
