<?php

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");

if ($_GET["variable"] == "euro" || $_GET["variable"] == "dolar") {

    include_once 'conexion.php';

    $sql = 'SELECT * FROM ' . $_GET["variable"];
    $sentencia = $mbd->prepare($sql);
    $sentencia->execute();
    $resultado = $sentencia->fetchAll();
    echo json_encode($resultado);
} else {
    echo "petion mala";
}
