<?php

session_start();

include_once '../coloresBD/conexion.php';

$usuario_login = $_POST['nombreUsuario'];
$contrasena_login = $_POST['contrasena'];


$sql = 'SELECT * FROM usuarios WHERE nombre=?';
$sentencia_verificar = $mbd->prepare($sql);
$sentencia_verificar->execute(array($usuario_login));

$res = $sentencia_verificar->fetch();


if ($res) {
    //ejecutar resto de codigo
    if (password_verify($contrasena_login, $res['contrasena'])) {
        echo 'todo bello';
        $_SESSION["admin"] = $usuario_login;
        header("Location: restringido.php");
    } else {
        echo 'Contraseña invalida';
        die();
    }
} else {
    echo 'Usuario inexistente';
    die();
}
