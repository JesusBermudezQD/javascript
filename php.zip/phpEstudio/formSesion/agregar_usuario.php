<?php
include_once '../coloresBD/conexion.php';
//echo password_hash("chechu", PASSWORD_DEFAULT) . "\n";

$usuario_nuevo = $_POST['nombreUsuario'];
$contrasena = $_POST['contrasena'];
$contrasena2 = $_POST['contrasenaR'];

//validar usuario existente

$sql = 'SELECT * FROM usuarios WHERE nombre=?';
$sentencia_verificar = $mbd->prepare($sql);
$sentencia_verificar->execute(array($usuario_nuevo));

$res = $sentencia_verificar->fetch();

if (!$res) {
    $contrasena = password_hash($contrasena, PASSWORD_DEFAULT);

    $hash = $contrasena;

    echo '<pre>';
    var_dump($usuario_nuevo);
    var_dump($contrasena);
    var_dump($contrasena2);
    echo '</pre>';

    if (password_verify($contrasena2, $hash)) {


        $sql_agregar = 'INSERT INTO usuarios(nombre,contrasena) VALUES (?,?)';
        $sentencia_agregar = $mbd->prepare($sql_agregar);


        if ($sentencia_agregar->execute(array($usuario_nuevo, $contrasena))) {
            echo "Agregado <br>";
        } else {
            echo "Error<br>";
        }

        //cerramos conexion base de datos y sentencia
        $sentencia_agregar = null;
        $mbd = null;

        //header('location:index.php');
    } else {
        echo "no valido";
    }
} else {
    echo 'Usuario en uso pruebe con otro';
    die();
}
