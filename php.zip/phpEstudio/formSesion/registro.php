<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>
    <div class="container mt-5" style="width: 500px;">
        <h1 class="text-center">REGISTRO</h1>
        <form action="agregar_usuario.php" method="POST">
            <div class="form-group">
                <input type="text" class="form-control mb-3" name="nombreUsuario" placeholder="Nombre de Usuario">
                <input type="text" class="form-control mb-3" name="contrasena" placeholder="Contraseña">
                <input type="text" class="form-control mb-3" name="contrasenaR" placeholder="Repita la Contraseña">
                <button class="btn btn-primary btn-block">Registrar</button>
            </div>

        </form>


        <h1 class="text-center">LOGIN</h1>
        <form action="inicio.php" method="POST">
            <div class="form-group">
                <input type="text" class="form-control mb-3" name="nombreUsuario" placeholder="Nombre de Usuario">
                <input type="text" class="form-control mb-3" name="contrasena" placeholder="Contraseña">
                <button class="btn btn-primary btn-block">Iniciar</button>
            </div>

        </form>

    </div>

</body>

</html>