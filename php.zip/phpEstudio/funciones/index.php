<?php

function lorem()
{
    return "
        <p>
            Lorem ipsum dolor sit amet consectetur adipisicing elit. 
            Perspiciatis mollitia quae voluptatum, tenetur quasi, 
            architecto eos a excepturi rerum libero delectus earum omnis exercitationem adipisci veritatis? 
            Totam nihil aspernatur et.
        </p>
    ";
}

function operacion($n1, $n2)
{
    return $n1 + $n2;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <section>
        <?php echo lorem(); ?>
    </section>

    <div>
        <?php echo operacion(123, 5); ?>
    </div>

    <footer>
        <h1>Derechos Reservados <?php echo date('Y'); ?></h1>
    </footer>
</body>

</html>