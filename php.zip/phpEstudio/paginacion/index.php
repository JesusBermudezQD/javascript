<?php
include_once "conexion.php";

//traer datos

$sql = 'SELECT * FROM `paginacion`';
$sentencia = $mbd->prepare($sql);
$sentencia->execute();
$datos = $sentencia->fetchAll();

$articulosPorPagina = 3;
$paginas = $sentencia->rowCount() / 3;

$paginas = ceil($paginas);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <title>Document</title>
</head>

<body>

    <div class="container mt-5">

        <h1 class="mb-5">Paginacion</h1>

        <?php
        if (!$_GET) {
            header("location: index.php?pagina=1");
        }

        $iniciar = ($_GET['pagina'] - 1) * $articulosPorPagina;

        $sql_articulo = 'SELECT * FROM paginacion LIMIT :iniciar,:nArticulos';
        $sentencia_articulo = $mbd->prepare($sql_articulo);
        $sentencia_articulo->bindParam(':iniciar', $iniciar, PDO::PARAM_INT);
        $sentencia_articulo->bindParam(':nArticulos', $articulosPorPagina, PDO::PARAM_INT);
        $sentencia_articulo->execute();
        $respuesta_articulo = $sentencia_articulo->fetchAll();

        ?>

        <?php foreach ($respuesta_articulo as $articulo) : ?>
            <div class="alert alert-primary" role="alert">
                <?php echo $articulo['titulo'] ?>
            </div>
        <?php endforeach ?>
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item <?php echo $_GET['pagina'] <= 1  ? 'disabled' : '' ?>">
                    <a class="page-link" href="index.php?pagina=<?php echo $_GET['pagina'] - 1 ?>" aria-label="Previous">
                        <span aria-hidden="true">&laquo;</span>
                    </a>
                </li>
                <?php for ($i = 1; $i <= $paginas; $i++) : ?>
                    <li class="page-item <?php echo $_GET['pagina'] == $i  ? 'active' : '' ?>">
                        <a class="page-link" href="index.php?pagina=<?php echo $i ?>">
                            <?php echo $i ?>
                        </a>
                    </li>
                <?php endfor ?>
                <li class="page-item <?php echo $_GET['pagina'] == $paginas  ? 'disabled' : '' ?>">
                    <a class="page-link " href="index.php?pagina=<?php echo $_GET['pagina'] + 1 ?>" aria-label="Next">
                        <span aria-hidden="true">&raquo;</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>

</body>

</html>