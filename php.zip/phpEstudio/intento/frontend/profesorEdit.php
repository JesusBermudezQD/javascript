<?php
include_once "../php/conexion.php";
session_start();

if (isset($_SESSION["admin"])) {
} else {
    header("Location: index.php");
}

//traer usuario
$id = $_GET['id'];
$sql = 'SELECT * FROM usuarios WHERE id=?';
$sentecia_traer = $mbd->prepare($sql);
$sentecia_traer->execute(array($id));
$respuesta = $sentecia_traer->fetch();
?>

<?php include("superior.php") ?>

<div class="container-fluid tam">
    <div class="row">
        <div class="col-2 p-0">
            <?php include("menu.php") ?>
        </div>
        <div class="col-10">
            <div class="form-inline float-right mt-2">
                <h5><?php echo $_SESSION["admin"]; ?></h5>
                <a href="../php/cerrarAdmin.php" class="btn btn-outline-danger my-2 my-sm-0 ml-5">Salir</a>
            </div>

            <h1 class="mt-5">Profesores</h1>
            <hr>
            <div class="form-inline float-right mb-3">
                <a href="profesores.php" class="btn btn-info my-2 my-sm-0 ">volver</a>
            </div>
            <form method="POST" action="../php/editar_profesor.php">
                <div class="form-group">
                    <label for="exampleInputEmail1">Nombre</label>
                    <input type="text" class="form-control" name="nombre" value="<?php echo $respuesta['nombre'] ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Contraseña</label>
                    <input type="password" class="form-control" name="contrasena" value="<?php echo $respuesta['contrasena'] ?>">
                </div>
                <div class="form-group">
                    <label for="exampleInputPassword1">Repita la Contraseña</label>
                    <input type="password" class="form-control" name="contrasenaR">
                </div>
                <div class="form-group">
                    <input type="hidden" class="form-control" name="rol" value="profesor">
                    <input type="hidden" class="form-control" name="id" value="<?php echo $id ?>">
                </div>
                <button type="submit" class="btn btn-primary btn-block mb-3">Actualizar</button>
            </form>

        </div>
    </div>

</div>


<?php include("inferior.php") ?>