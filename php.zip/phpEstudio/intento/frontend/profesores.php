<?php
include_once "../php/conexion.php";
session_start();

if (isset($_SESSION["admin"])) {
} else {
    header("Location: index.php");
}

//traer usuarios

$sql = 'SELECT * FROM usuarios';
$sentecia_traer = $mbd->prepare($sql);
$sentecia_traer->execute();
$respuesta = $sentecia_traer->fetchAll();

/* var_dump($respuesta); */
?>

<?php include("superior.php") ?>

<div class="container-fluid tam">
    <div class="row">
        <div class="col-2 p-0">
            <?php include("menu.php") ?>
        </div>
        <div class="col-10">
            <div class="form-inline float-right mt-2">
                <h5><?php echo $_SESSION["admin"]; ?></h5>
                <a href="../php/cerrarAdmin.php" class="btn btn-outline-danger my-2 my-sm-0 ml-5">Salir</a>
            </div>

            <h1 class="mt-5">Profesores</h1>
            <hr>
            <div class="form-inline float-right mb-3">
                <a href="" class="btn btn-info my-2 my-sm-0 " data-toggle="modal" data-target="#agregarProfesor">Agregar Profesor</a>
            </div>

            <div class="table-responsive-lg mt-3">
                <table class="table text-center shadow">
                    <thead class="thead-dark">
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">nombre</th>
                            <th scope="col">Contraseña</th>
                            <th scope="col">Opciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($respuesta as $profesor) : ?>
                            <?php if ($profesor["rol"] != "admin") : ?>
                                <tr>
                                    <th scope="row"><?php echo $profesor["id"] ?></th>
                                    <td><?php echo $profesor["nombre"] ?></td>
                                    <td><?php echo $profesor["contrasena"] ?></td>
                                    <td>
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                            <a href="profesorEdit.php?id=<?php echo $profesor["id"] ?>" class="btn btn-success  btn-sm text-white">
                                                <span class="material-icons" style="font-size: 20px;">
                                                    edit
                                                </span>
                                            </a>
                                            <a href="../php/eliminar_profesor.php?id=<?php echo $profesor["id"] ?>" class="btn btn-danger btn-sm text-white">
                                                <span class="material-icons" style="font-size: 20px;">
                                                    delete
                                                </span>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                            <?php endif ?>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Modal agregar profesor -->
    <div class="modal fade" id="agregarProfesor" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Agregar Profesor</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="POST" action="../php/agregar_profesor.php">
                        <div class="form-group">
                            <label for="exampleInputEmail1">Nombre</label>
                            <input type="text" class="form-control" name="nombre">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Contraseña</label>
                            <input type="password" class="form-control" name="contrasena">
                        </div>
                        <div class="form-group">
                            <label for="exampleInputPassword1">Repita la Contraseña</label>
                            <input type="password" class="form-control" name="contrasenaR">
                        </div>
                        <div class="form-group">
                            <input type="hidden" class="form-control" name="rol" value="profesor">
                        </div>
                </div>
                <button type="submit" class="btn btn-primary mb-3 ml-3 mr-3">Submit</button>
                </form>
            </div>
        </div>
    </div>

</div>
</div>

<?php include("inferior.php") ?>