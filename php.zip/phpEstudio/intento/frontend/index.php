<?php
?>


<?php include("superior.php") ?>

<div class="container">
    <h1 class="text-center mt-5">LOGIN</h1>
    <form action="../php/sesionAdmin.php" method="POST">
        <div class="form-group">
            <input type="text" class="form-control mb-3" name="nombreUsuario" placeholder="Nombre de Usuario">
            <input type="text" class="form-control mb-3" name="contrasena" placeholder="Contraseña">
            <input type="hidden" class="form-control mb-3" name="rol" value="admin">
            <button class="btn btn-primary btn-block">Iniciar</button>
        </div>

    </form>
</div>

<?php include("inferior.php") ?>