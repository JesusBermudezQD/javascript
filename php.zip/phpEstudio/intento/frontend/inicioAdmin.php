<?php
session_start();

if (isset($_SESSION["admin"])) {
} else {
    header("Location: index.php");
}
?>

<?php include("superior.php") ?>

<div class="container-fluid tam">
    <div class="row">
        <div class="col-2 p-0">
            <?php include("menu.php") ?>
        </div>
        <div class="col-10">
            <div class="form-inline float-right mt-2">
                <h5><?php echo $_SESSION["admin"]; ?></h5>
                <a href="../php/cerrarAdmin.php" class="btn btn-outline-danger my-2 my-sm-0 ml-5">Salir</a>
            </div>

            <h1 class="text-center mt-5">BIENVENIDO</h1>
        </div>
    </div>
</div>

<?php include("inferior.php") ?>