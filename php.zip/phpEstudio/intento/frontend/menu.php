<div class="bg-light tam ">
    <nav class="shadow navbar navbar-dark bg-dark ">
        <a href="inicioAdmin.php" class="navbar-brand">Dashboard</a>
    </nav>
    <a href="cursos.php" class="d-block  mt-3 ml-4" style="text-decoration: none;">
        <span class="material-icons">local_library</span> Cusos
    </a>
    <a href="profesores.php" class="d-block  mt-3 ml-4" style="text-decoration: none;">
        <span class="material-icons">people</span> Profesores
    </a>
</div>

<style>
    a {
        color: black;
    }

    a:hover {
        border-bottom: 1px solid gray;
    }
</style>