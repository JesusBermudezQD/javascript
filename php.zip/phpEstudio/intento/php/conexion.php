<?php

$link = 'mysql:host=localhost;dbname=intento';
$usuario = "root";
$contrasena = "";
try {
    $mbd = new PDO($link, $usuario, $contrasena);
    /* echo "conectado"; */
} catch (PDOException $e) {
    print "¡Error!: " . $e->getMessage() . "<br/>";
    die();
}
