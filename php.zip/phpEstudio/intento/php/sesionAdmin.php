<?php

session_start();
include_once '../php/conexion.php';

$usuario_login = $_POST['nombreUsuario'];
$contrasena_login = $_POST['contrasena'];
$rol = $_POST['rol'];

echo $usuario_login;
echo $contrasena_login;
echo $rol;

$sql = 'SELECT * FROM usuarios WHERE rol=?';
$sentecia = $mbd->prepare($sql);
$sentecia->execute(array($rol));

$res = $sentecia->fetch();

echo json_encode($res);

if ($res) {
    //ejecutar resto de codigo
    if ($contrasena_login == $res['contrasena']) {
        echo 'todo bello';
        $_SESSION["admin"] = $usuario_login;
        header("Location: ../frontend/inicioAdmin.php");
    } else {
        echo 'Contraseña invalida';
        die();
    }
} else {
    echo 'Usuario inexistente';
    die();
}
