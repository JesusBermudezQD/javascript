<?php
//editar.php?id=1&color=success&descripcion=ahora eres verde perro
include_once "../php/conexion.php";

$id = $_POST['id'];
$nombre = $_POST['nombre'];
$contrasena = $_POST['contrasena'];
$contrasenaR = $_POST['contrasenaR'];
$rol = $_POST['rol'];

$contrasena = password_hash($contrasena, PASSWORD_DEFAULT);
$hash = $contrasena;

if (password_verify($contrasenaR, $hash)) {
    $sql_editar = 'UPDATE usuarios SET rol=?,nombre=?,contrasena=? WHERE id=?';
    $sentencia_editar = $mbd->prepare($sql_editar);
    $sentencia_editar->execute(array($rol, $nombre, $contrasena, $id));
    header('location:../frontend/profesores.php');
}

$sentencia_editar = null;
$mbd = null;
