<?php
include_once "../php/conexion.php";

$nombre_profesor = $_POST["nombre"];
$contrasena = $_POST["contrasena"];
$contrasenaR = $_POST["contrasenaR"];
$rol = $_POST["rol"];

//validar si existe el usuario

$sql = 'SELECT * FROM usuarios WHERE  nombre=?';
$sentencia_verificar = $mbd->prepare($sql);
$sentencia_verificar->execute(array($nombre_profesor));

$res_verificar = $sentencia_verificar->fetch();


if (!$res_verificar) {
    $contrasena = password_hash($contrasena, PASSWORD_DEFAULT);
    $hash = $contrasena;

    if (password_verify($contrasenaR, $hash)) {
        $sql_agregar = 'INSERT INTO usuarios(rol,nombre,contrasena) VALUES (?,?,?)';
        $sentencia_agregar = $mbd->prepare($sql_agregar);
        $sentencia_agregar->execute(array($rol, $nombre_profesor, $contrasena));

        $sentencia_agregar = null;
        $mbd = null;

        header('location:../frontend/profesores.php');
    } else {
        echo "contraeñas invalidas";
    }
} else {
    echo "usuario en uso";
    die();
}
