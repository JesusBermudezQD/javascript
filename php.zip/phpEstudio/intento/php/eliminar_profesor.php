<?php
$id = $_GET['id'];

include_once "../php/conexion.php";

$sql_eliminar = 'DELETE FROM `usuarios` WHERE `usuarios`.`id` = ?';
$sentencia_eliminar = $mbd->prepare($sql_eliminar);
$sentencia_eliminar->execute(array($id));

$sentencia_eliminar = null;
$mbd = null;

header('location:../frontend/profesores.php');
