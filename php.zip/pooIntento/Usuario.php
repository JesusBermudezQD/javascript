<?php
require_once("Autoload.php");

class Usuario extends Conexion
{
    private $strNombre;
    private $intTelefono;
    private $strEmail;
    private $id;

    public function insertUsuario(string $nombre,  int $telefono, string $email)
    {

        $this->strNombre = $nombre;
        $this->intTelefono = $telefono;
        $this->strEmail = $email;

        $sql = "INSERT INTO usuarios(nombre,telefono,email) VALUES (?,?,?)";
        $insert = Conexion::conectar()->prepare($sql);
        $arrData = array($this->strNombre, $this->intTelefono, $this->strEmail);
        return $insert->execute($arrData);
    }


    public function mostUsuarios()
    {
        $sql = 'SELECT *FROM usuarios';
        $mostrar = Conexion::conectar()->prepare($sql);
        $mostrar->execute();
        return $mostrar->fetchAll();
    }

    public function elimUsuario(int $id)
    {
        $sql = 'DELETE FROM `usuarios` WHERE `usuarios`.`id` = ?';
        $eliminar = Conexion::conectar()->prepare($sql);
        return $eliminar->execute(array($id));
    }

    public function editUsuario(int $id, string $nombre, string $telefono, string $email)
    {
        $this->strNombre = $nombre;
        $this->intTelefono = $telefono;
        $this->strEmail = $email;

        echo $this->strNombre;
        echo $this->intTelefono;
        echo $this->strEmail;
        echo $id;
        $sql = 'UPDATE usuarios SET nombre = ?, telefono = ?, email = ? WHERE `usuarios`.`id` = ?';
        $editar = Conexion::conectar()->prepare($sql);
        $arrData = array($nombre, $telefono, $email, $id);
        $editar->execute($arrData);
    }

    public function mostUsuario(int $id)
    {
        $sql = 'SELECT * FROM usuarios WHERE id=?';
        $mostrar = Conexion::conectar()->prepare($sql);
        $mostrar->execute(array($id));
        return $mostrar->fetch();
    }
}
