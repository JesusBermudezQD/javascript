<?php

class Conexion
{
    private $host = "localhost";
    private $usuario = "root";
    private $contrasena = "";
    private $db = "prueba";
    private $conect;

    public function conectar()
    {
        try {
            $connectionString = "mysql:host=" . $this->host . ";dbname=" . $this->db . ";charset=utf8";
            $con = $this->conect = new PDO($connectionString, $this->usuario, $this->contrasena);
            return $con;
            echo "conectado";
        } catch (PDOException $e) {
            $this->conect = "Error en Conexion";
            echo "ERROR: " . $e->getMessage();
        }
    }
}
