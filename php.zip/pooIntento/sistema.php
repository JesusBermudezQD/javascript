<?php

require_once("Autoload.php");

$objUsuario = new Usuario();

//insertar
/* $insert = $objUsuario->insertUsuario('calor', 12345431, 'pepe@info.com'); */

//mostrar

$mostrar = $objUsuario->mostUsuarios();

var_dump(json_encode($mostrar));

//eliminar
/*$eliminar = $objUsuario->elimUsuario(2); */

//editar 

//$editar = $objUsuario->editUsuario(15, "cambio", 12341234, "chechu12@gmail.com");
echo "</br>---------------------------------------------------------</br>";

$mostrarUsuario = $objUsuario->mostUsuario(15);

var_dump(json_encode($mostrarUsuario));
