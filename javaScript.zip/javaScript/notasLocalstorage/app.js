const listaNotas = document.getElementById("lista-notas");

eventListener();

function eventListener() {
  document.querySelector("#formulario").addEventListener("submit", agregarNota);

  listaNotas.addEventListener("click", borrarNota);

  document.addEventListener("DOMContentLoaded", mostrarDelLocal);
}

//agregar nota al DOM
function agregarNota(e) {
  e.preventDefault();
  const nota = {
    titulo: "",
    descripcion: "",
  };

  nota.titulo = document.getElementById("titulo").value;
  nota.descripcion = document.getElementById("descripcion").value;

  const card1 = `<div class="d-inline-block mt-2" cols="3">
                  <div class="card" style="width: 16rem;">
                    <div class="card-body">
                      <h5 class="card-title">${nota.titulo}</h5>
                      <p class="card-text">${nota.descripcion}</p>
                      <a href="#" id="borrar" class="btn btn-danger btn-block btn-sm">Borrar</a>
                    </div>
                  </div>
                </div>`;

  q = document.getElementById("lista-notas").innerHTML;

  document.getElementById("lista-notas").innerHTML = card1 + q;

  guardarLocal(nota);
}

//agregar al DOM desde el local

function mostrarDelLocal() {
  let notas;

  notas = obtenerNotas();

  notas.forEach((nota) => {
    const card1 = `<div class="d-inline-block mt-2" cols="3">
                    <div class="card" style="width: 16rem;">
                      <div class="card-body">
                        <h5 class="card-title" id="titulo">${nota.titulo}</h5>
                        <p class="card-text" id="descripcion">${nota.descripcion}</p>
                        <a href="#" id="borrar" class="btn btn-danger btn-block btn-sm">Borrar</a>
                      </div>
                    </div>
                  </div>`;

    q = document.getElementById("lista-notas").innerHTML;

    document.getElementById("lista-notas").innerHTML = card1 + q;
  });
}

//guardar notas en el local

function guardarLocal(nota) {
  let notas;
  notas = obtenerNotas();

  notas.push(nota);

  localStorage.setItem("notas", JSON.stringify(notas));
}

//borrar nota del DOM

function borrarNota(e) {
  e.preventDefault();

  if (e.target.id === "borrar") {
    const nota = e.target.parentElement.parentElement;
    e.target.parentElement.parentElement.remove();

    leerDatos(nota);
  }
}

//leer info de la nota

function leerDatos(nota) {
  const datosNota = {
    titulo: nota.querySelector("h5").textContent,
    descripcion: nota.querySelector("p").textContent,
  };

  borrarNotaLocal(datosNota);
}

//obtener notas del local se comprueba si hay y si no hay

function obtenerNotas() {
  let notas;

  if (localStorage.getItem("notas") === null) {
    notas = [];
  } else {
    notas = JSON.parse(localStorage.getItem("notas"));
  }

  return notas;
}

//borrar del local

function borrarNotaLocal(datosNota) {
  let notas;

  //eliminando texto extra
  notas = obtenerNotas();
  notas.forEach(function (nota, index) {
    if (
      nota.titulo === datosNota.titulo &&
      nota.descripcion === datosNota.descripcion
    ) {
      notas.splice(index, 1);
    }
  });
  console.log(notas);
  localStorage.setItem("notas", JSON.stringify(notas));
}
