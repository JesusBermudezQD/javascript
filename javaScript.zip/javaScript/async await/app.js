async function leerTodos() {
  //esperar la respuesta

  const respuesta = await fetch("https://jsonplaceholder.typicode.com/todos");

  //sigue cuando la respuesta llego

  const datos = await respuesta.json();

  return datos;
}

leerTodos().then((usuarios) => console.log(usuarios));
