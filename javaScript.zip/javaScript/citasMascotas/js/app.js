let DB;

//seleccionando datos

const form = document.querySelector("#form"),
  nombreMascota = document.querySelector("#nombreMascota"),
  nombreDueño = document.querySelector("#nombreDueño"),
  telefono = document.querySelector("#telefono"),
  fecha = document.querySelector("#fecha"),
  hora = document.querySelector("#hora"),
  sintomas = document.querySelector("#sintomas"),
  citas = document.querySelector("#citas");

//esperar que el DOM este cargado

document.addEventListener("DOMContentLoaded", () => {
  //creando la base de datos

  let creaDB = window.indexedDB.open("citas", 1);

  //si hay algun error

  creaDB.onerror = function () {
    console.log("Error Perro");
  };

  //todo bien, se asigna la base de datos y se muetsra mensaje en consola

  creaDB.onsuccess = function () {
    //console.log("Todo Listo");

    DB = creaDB.result;
  };

  //este metodo se ejecuta una vez y sirve para crear el schema

  creaDB.onupgradeneeded = function () {};
});
