/* document.getElementById("app").innerHTML="hola chechu" 

let nombre = prompt("Cual es tu nombre?")

document.getElementById('app').innerHTML=`Bienvenido ${nombre}`;

let texto="hola chechu aldo";

console.log(texto.indexOf("chechu"));*/


let arreglo=[1,3,9,0,5,7,1];

arreglo.sort();
console.log(arreglo);

