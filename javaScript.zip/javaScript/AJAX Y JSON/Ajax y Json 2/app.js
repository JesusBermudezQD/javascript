const divHTML = document.getElementById("listado");
const boton1 = document
  .getElementById("boton1")
  .addEventListener("click", cargarApiPosts);

const boton2 = document
  .getElementById("boton2")
  .addEventListener("click", cargarApiUsuarios);

//mostrando post en concreto desde una API con ajax

function cargarApiPosts() {
  const xhr = new XMLHttpRequest();

  xhr.open("GET", "https://jsonplaceholder.typicode.com/posts", true);

  xhr.onload = function () {
    if (this.status === 200) {
      const posts = JSON.parse(this.responseText);

      let htmlTemplete = "";
      posts.forEach((post) => {
        htmlTemplete += `
                <div class="card">
                  <div class="card-header">${post.title}</div>
                  <div class="card-body">
                    <p class="card-text">${post.body}</p>
                  </div>
                </div>
                <br>
        `;
      });

      divHTML.innerHTML = htmlTemplete;
    }
  };

  xhr.send();
}

function cargarApiUsuarios() {
  const xhr = new XMLHttpRequest();

  xhr.open("GET", "https://jsonplaceholder.typicode.com/users", true);

  xhr.onload = function () {
    if (this.status === 200) {
      const users = JSON.parse(this.responseText);
      let htmlTemplete = "";
      users.forEach((user) => {
        htmlTemplete += `
        <div class="card bg-light" style="max-width: 40rem;">
          <div class="card-header">Datos Usuario</div>
          <div class="card-body">
            <p class="card-text">Nombre: ${user.name}</p>
            <p class="card-text">Usuario: ${user.username}</p>
            <p class="card-text">Email: ${user.email}</p>
            <p class="card-text">Telefono: ${user.phone}</p>
            <p class="card-text">Sitio Web: ${user.website}</p>
          </div>
        </div>
        <br>
        `;
      });
      divHTML.innerHTML = htmlTemplete;
    }
  };

  xhr.send();
}
