document.getElementById("txtBtn").addEventListener("click", cargarTxt);
document.getElementById("jsonBtn").addEventListener("click", cargarJson);
document.getElementById("apiBtn").addEventListener("click", cargarApi);
const resultado = document.getElementById("resultado");

function cargarTxt() {
  fetch("datos.txt")
    .then((res) => res.text())
    .then((data) => (resultado.innerHTML = data))
    .catch((error) => console.log(error));
}

function cargarJson() {
  let htmlTemplete = "";
  fetch("empleados.json")
    .then((res) => res.json())
    .then((data) => {
      data.forEach((elem) => {
        htmlTemplete += `
                    <ul>
                        <li>Nombre: ${elem.nombre}</li>
                        <a>Cargo: ${elem.puesto}</a>
                    </ul>
                    <---------------------------->            
            `;
      });
      resultado.innerHTML = htmlTemplete;
    })
    .catch((error) => console.log(error));
}

//https://picsum.photos/list link api

function cargarApi() {
  let htmlTemplete = "";
  fetch("https://picsum.photos/list")
    .then((res) => res.json())
    .then((data) => {
      data.forEach((img) => {
        htmlTemplete += `
                        <ul>
                            <li>
                                ${img.author}
                                <a href="${img.post_url}">Ver Imagen</a>
                            </li>
                        </ul>
          `;
      });
      resultado.innerHTML = htmlTemplete;
    })
    .catch((error) => console.log(error));
}
