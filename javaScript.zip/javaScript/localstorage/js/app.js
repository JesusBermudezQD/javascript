//capturando div padre de las notas
const listaNotas = document.getElementById("lista-notas");

//Event listeners

eventListener();

function eventListener() {
  //Envio de formulario

  document.querySelector("#formulario").addEventListener("submit", agregarNota);
  //borrar nota
  listaNotas.addEventListener("click", borrarNota);

  //cargando el contenido
  document.addEventListener("DOMContentLoaded", localStorageListo);
}

//funciones

function agregarNota(e) {
  e.preventDefault();

  //capturando texto
  const nota = document.getElementById("nota").value;

  //agregarndo boton eliminar
  const botonBorrar = document.createElement("a");
  botonBorrar.classList = "btn btn-danger btn-sm text-white";
  botonBorrar.setAttribute("style", "float: right; ");
  botonBorrar.setAttribute("id", "borrar");
  botonBorrar.innerText = "x";

  //agregando texto y estilos a la etiqueta
  const li = document.createElement("li");
  li.innerText = nota;
  li.classList = "m-3";
  li.appendChild(botonBorrar);
  //agregando a la lista
  listaNotas.appendChild(li);

  guardarlocal(nota);
  nota.value = "";
}

//agragando al local
function guardarlocal(nota) {
  let notas;
  notas = obtenerNotas();

  //añadir nueva nota
  notas.push(nota);

  //convertir string a arreglo para el localporque esa vaina viene en formato JSON y se le pasa el arreglo notas para convertirlo
  localStorage.setItem("notas", JSON.stringify(notas));
}

//mostrar datos del local

function localStorageListo() {
  let notas;

  notas = obtenerNotas();

  notas.forEach((nota) => {
    //agregarndo boton eliminar
    const botonBorrar = document.createElement("a");
    botonBorrar.classList = "btn btn-danger btn-sm text-white";
    botonBorrar.setAttribute("style", "float: right; ");
    botonBorrar.setAttribute("id", "borrar");
    botonBorrar.innerText = "x";

    //agregando texto y estilos a la etiqueta
    const li = document.createElement("li");
    li.innerText = nota;
    li.classList = "m-3";
    li.appendChild(botonBorrar);
    //agregando a la lista
    listaNotas.appendChild(li);
  });
}

//obtenerNotas comprobar que hay elementos en el local storage y retorna un arreglo
function obtenerNotas() {
  let notas;
  if (localStorage.getItem("notas") === null) {
    notas = [];
  } else {
    notas = JSON.parse(localStorage.getItem("notas"));
  }
  return notas;
}

//eliminar nota del DOM
function borrarNota(e) {
  e.preventDefault();

  if (e.target.id === "borrar") {
    e.target.parentElement.remove();
    borrarNotaLocalStorage(e.target.parentElement.innerText);
  }
}

//eliminar nota del local storage

function borrarNotaLocalStorage(nota) {
  let notas, notaBorrar;

  //elimina la x del texto obtenido
  notaBorrar = nota.substring(0, nota.length - 1);

  notas = obtenerNotas();

  notas.forEach(function (nota, index) {
    if (notaBorrar === nota) {
      notas.splice(index, 1);
    }
  });

  localStorage.setItem("notas", JSON.stringify(notas));
}
