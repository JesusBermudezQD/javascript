class Interfaz {
  constructor() {
    this.Init();
  }

  Init() {
    this.construirSelect();
  }

  mostrarMensaje(mensaje) {
    const div = document.createElement("div");
    div.classList.add("alert", "alert-danger", "text-center");
    div.appendChild(document.createTextNode(mensaje));
    document.querySelector(".mensajes").appendChild(div);

    setTimeout(() => {
      document.querySelector(".mensajes div").remove();
    }, 2000);
  }

  construirSelect() {
    const criptomoneda = document.querySelector("#criptomoneda");
    cotizador.obtenerMonedasAPI().then((monedas) => {
      for (const [key, value] of Object.entries(monedas.monedas.Data)) {
        //agregando nombre y value

        const opcion = document.createElement("option");
        opcion.value = value.Symbol;
        opcion.appendChild(document.createTextNode(value.CoinName));
        criptomoneda.appendChild(opcion);
      }
    });
  }

  imprimirResultadoCotizacion(resultado, moneda, crypto) {
    const resultadoAnterior = document.querySelector("#resultado>div");
    if (resultadoAnterior) {
      resultadoAnterior.remove();
    }

    const datosMoneda = resultado[crypto][moneda];
    console.log(resultado[crypto][moneda]);

    let precio = datosMoneda.PRICE.toFixed(2),
      porcentaje = datosMoneda.CHANGEPCTDAY.toFixed(2),
      actualizado = new Date(datosMoneda.LASTUPDATE * 1000).toLocaleDateString(
        "es-CO"
      );

    let htmlTemplete = `
          <div class="card bg-info">
            <div class="card-body text-light">
              <h2 class="card-title">Resultado:</h2>
              <p>El precios ${datosMoneda.FROMSYMBOL} 
                 a moneda ${datosMoneda.TOSYMBOL} 
                 es de $${precio} </p>
              <p>Variacion ultimo dia %${porcentaje}</p>
              <p> Ultima actualizacion ${actualizado}</p>
            </div>
          </div>
    `;

    this.mostrarSpinner();
    setTimeout(() => {
      document.getElementById("resultado").innerHTML = htmlTemplete;
      this.ocultarSpinner();
    }, 3000);
  }

  mostrarSpinner() {
    const spinner = document.querySelector(".contenido-spinner");
    spinner.style.display = "block";
  }

  ocultarSpinner() {
    const spinner = document.querySelector(".contenido-spinner");
    spinner.style.display = "none";
  }
}
