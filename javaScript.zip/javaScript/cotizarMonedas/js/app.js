//instanciando ui.js y api.js
const cotizador = new API(
  "64a52740f666728a79145799740611559c8ae4fc75a88d9134c4be726805bd56"
);
const ui = new Interfaz();

cotizador.obtenerMonedasAPI();

//optener formulario
const formulario = document.querySelector("#form");

formulario.addEventListener("submit", (e) => {
  e.preventDefault();

  //capturar datos

  const moneda = document.getElementById("moneda");
  const monedaSeleccionada = moneda.options[moneda.selectedIndex].value;

  const criptomoneda = document.getElementById("criptomoneda");
  const criptomonedaSeleccionada =
    criptomoneda.options[criptomoneda.selectedIndex].value;

  if (monedaSeleccionada === "" || criptomonedaSeleccionada === "") {
    //mostrar alerta de error
    ui.mostrarMensaje("Error seleccione todos los campos");
  } else {
    //consultar la API

    cotizador
      .obtenerValores(monedaSeleccionada, criptomonedaSeleccionada)
      .then((data) => {
        ui.imprimirResultadoCotizacion(
          data.resultado.RAW,
          monedaSeleccionada,
          criptomonedaSeleccionada
        );
      });
  }
});
