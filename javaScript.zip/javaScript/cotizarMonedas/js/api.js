class API {
  constructor(apikey) {
    this.apikey = apikey;
  }

  //obtener todas las monenas

  async obtenerMonedasAPI() {
    const url = `https://min-api.cryptocompare.com/data/all/coinlist?api_key=${this.apikey}`;

    //fech
    const urlObtenerMonedas = await fetch(url);

    //respuesta
    const monedas = await urlObtenerMonedas.json();

    return { monedas };
  }

  async obtenerValores(moneda, criptomoneda) {
    const url = `https://min-api.cryptocompare.com/data/pricemultifull?fsyms=${criptomoneda}&tsyms=${moneda}&api_key=${this.apikey}`;

    //consultar en la api
    const urlConvertir = await fetch(url);

    const resultado = await urlConvertir.json();

    return {
      resultado,
    };
  }
}
