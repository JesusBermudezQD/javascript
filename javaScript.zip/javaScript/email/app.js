//variables
const email = document.getElementById("email");
const asunto = document.getElementById("asunto");
const mensaje = document.getElementById("mensaje");
const btnEnviar = document.getElementById("enviar");
const btnBorrar = document.getElementById("limpiar");
const formularioEnviar = document.getElementById("enviar-email");
//event Listener

eventListeners();

function eventListeners() {
  //inicio de la aplicacion y deasbilitar el boton
  document.addEventListener("DOMContentLoaded", inicioApp);

  //campos del formulario

  email.addEventListener("blur", validarCampo);
  asunto.addEventListener("blur", validarCampo);
  mensaje.addEventListener("blur", validarCampo);

  //enviar email

  formularioEnviar.addEventListener("submit", enviarCorreo);

  //limpiar formulario
  btnBorrar.addEventListener("click", limpiarForm);
}
//funciones

function inicioApp() {
  //desabilitar envio

  btnEnviar.disabled = true;
}

//validacion si el campo tiene algo escrito
function validarCampo() {
  //validar longitud del campo
  validarLongitud(this);

  let errores = document.querySelectorAll(".error");
  console.log(errores.length);

  if (email.value !== "" && asunto.value !== "" && mensaje !== "") {
    if (errores.length === 0) {
      btnEnviar.disabled = false;
    } else {
      btnEnviar.disabled = true;
    }
  }
}
function enviarCorreo(e) {
  //mostrar spinner al presionar enviar

  const spinnerGif = document.querySelector("#spinner");
  spinnerGif.style.display = "block";

  //creando gif envia email
  const enviado = document.createElement("img");
  enviado.src = "img/mail.gif";
  enviado.style.display = "block";
  enviado.setAttribute("width", "150");

  setTimeout(function () {
    spinnerGif.style.display = "none";

    document.querySelector("#gifs").appendChild(enviado);

    setTimeout(function () {
      enviado.style.display = "none";
      formularioEnviar.reset();
    }, 3000);
  }, 3000);
  e.preventDefault();
}

//verifica la longitud del texto en todos los campos
function validarLongitud(campo) {
  if (campo.value.length > 0) {
    campo.style.borderBottomColor = "green";
    campo.classList.remove("error");
  } else {
    campo.style.borderBottomColor = "red";
    campo.classList.add("error");
  }
}

function limpiarForm(e) {
  formularioEnviar.reset();
  btnEnviar.disabled = true;
  email.style.borderBottomColor = "";
  asunto.style.borderBottomColor = "";
  mensaje.style.borderBottomColor = "";
  e.preventDefault();
}
