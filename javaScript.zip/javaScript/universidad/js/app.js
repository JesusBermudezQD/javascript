document.querySelector('#submit-buscador').addEventListener('click', function(e){
    e.preventDefault();
    alert("me lo undiste prro UwU");
});
