export const formulario = document.querySelector("#form"),
  divMensajes = document.querySelector("#mensajes"),
  divResultado = document.querySelector("#resultado");
