import * as UI from "./interfaz.js";
import { API } from "./api.js";

UI.formulario.addEventListener("submit", (e) => {
  e.preventDefault();

  //capturando variasbles de busqueda

  const artista = document.getElementById("artista").value,
    cancion = document.getElementById("cancion").value;

  if (artista === "" || cancion === "") {
    //mostrar error
    const div = document.createElement("div");
    div.innerHTML = "ERROR completa los campos cachon";
    div.classList.add("alert", "alert-danger", "text-center");

    UI.divMensajes.appendChild(div);

    setTimeout(() => {
      div.remove();
    }, 3000);
  } else {
    //consultar api
    const api = new API(artista, cancion);
    api.consultarAPI().then((data) => {
      if (data.respuesta.lyrics) {
        const letra = data.respuesta.lyrics;
        UI.divResultado.textContent = letra;
      } else {
        const div = document.createElement("div");
        div.innerHTML = "ERROR al encontrar la cancion compruebe los campos";
        div.classList.add("alert", "alert-danger", "text-center");

        UI.divMensajes.appendChild(div);

        setTimeout(() => {
          div.remove();
          UI.formulario.reset();
        }, 3000);
      }
    });
  }
});
