class Interfaz {
  constructor() {
    //inicializa la app al instanciar
    this.init();

    this.listado = document.getElementById("resultados");
  }

  //metodo para cuando se inicialice la app
  init() {
    this.imprimirCategorias();
  }

  //imprimir categorias

  imprimirCategorias() {
    const listaCategorias = eventbrite
      .obtenerCategorias()
      .then((categorias) => {
        const cats = categorias.categorias.categories;

        console.log(categorias.categorias.categories);

        //seleccionar el select de categorias

        const selectCategorias = document.querySelector("#categorias");

        cats.forEach((nombreEvents) => {
          const option = document.createElement("option");
          option.value = nombreEvents.id;
          option.appendChild(document.createTextNode(nombreEvents.name));

          selectCategorias.appendChild(option);
        });
      });
  }

  mostrarError(mensaje, tipo) {
    const res = document.querySelector(".btn");
    if (tipo === "error") {
      const div = document.createElement("div");
      div.classList.add("alert", "alert-danger", "text-center");
      div.innerHTML = mensaje;
      res.before(div);

      setTimeout(() => {
        div.remove();
      }, 3000);
    }
  }
}
