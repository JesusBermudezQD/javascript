class EventBrite {
  constructor() {
    this.token_auth = "5Y2B2BZ7RJEOWU36BPK2";
    this.ordenar = "date";
  }

  async obtenerCategorias() {
    //consultar categorias

    const respuestaCategorias = await fetch(
      `https://www.eventbriteapi.com/v3/categories/?token=${this.token_auth}`
    );

    //esperar las categorias y devolver el JSON

    const categorias = await respuestaCategorias.json();

    //devolver resultado

    return {
      categorias,
    };
  }

  async obtenerEventos(evento, categoria) {
    const respuestaEventos = await fetch(``);
  }
}
