const eventbrite = new EventBrite();
const ui = new Interfaz();

const formulario = document.querySelector("#form");

formulario.addEventListener("submit", (e) => {
  e.preventDefault();
  const evento = document.getElementById("evento").value;
  const categoria = document.getElementById("categorias");
  const categoriaSeleccionada =
    categoria.options[categoria.selectedIndex].value;

  if (evento !== "") {
    //consultar la api
    eventbrite.obtenerEventos(evento, categoriaSeleccionada);
  } else {
    //campos basios
    ui.mostrarError("Complete los campos", "error");
  }
});
