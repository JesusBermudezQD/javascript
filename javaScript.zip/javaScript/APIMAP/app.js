const ui = new Interfaz();

document.addEventListener("DOMContentLoaded", () => {
  ui.mostrarEstablecimientos();
});

//buscar establecimientos

const buscador = document.querySelector("#form input");

buscador.addEventListener("input", () => {
  if (buscador.value.length > 5) {
    //buscar en la api
    ui.obtenerSugerencias(buscador.value);
  } else {
    ui.mostrarEstablecimientos();
  }
});
