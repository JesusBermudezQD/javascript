class Interfaz {
  constructor() {
    //instanciar api
    this.api = new API();
    //crear markers con layerGroup

    this.markers = new L.LayerGroup();
    //iniciar mapa
    this.mapa = this.inicializarMapa();
  }

  inicializarMapa() {
    const map = L.map("mapa").setView([19.390519, -99.3739778], 6);

    const enlaceMapa = '<<a href="http://openstreetmap.org">OpenStreetMap</a>';

    L.tileLayer("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      attribution:
        "Map data &copy;" +
        enlaceMapa +
        'contributors, <a href="http://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="http://cloudmade.com">CloudMade</a>',
      maxZoom: 18,
    }).addTo(map);

    return map;
  }

  mostrarEstablecimientos() {
    this.api.obtenerDatos().then((datos) => {
      const resultado = datos.respuestaJson.results;
      this.mostrarPines(resultado);
    });
  }

  mostrarPines(datos) {
    //limpiar los markers
    this.markers.clearLayers();

    //recorrer los establecimientos

    datos.forEach((dato) => {
      const { longitude, latitude, calle, regular, premium } = dato;

      //crear popup
      const opcionesPopUp = L.popup().setContent(
        `<p>Calle: ${calle}</p>
          <p>Gasolina Regular: $${regular}</p>
          <p>Gasolina Premium: $${premium}</p>`
      );
      //agregar pin

      const marker = new L.marker([
        parseFloat(latitude),
        parseFloat(longitude),
      ]).bindPopup(opcionesPopUp);

      this.markers.addLayer(marker);
    });

    this.markers.addTo(this.mapa);
  }

  obtenerSugerencias(busqueda) {
    this.api.obtenerDatos().then((datos) => {
      //traer todos los datos
      const resultados = datos.respuestaJson.results;

      //enviar respuesta y filtrado
      this.filtrarSugerencia(resultados, busqueda);
    });
  }

  filtrarSugerencia(resultado, busqueda) {
    //filtrar con filter
    const filtro = resultado.filter(
      (filtro) => filtro.calle.indexOf(busqueda) !== -1
    );

    console.log(filtro);

    //mostrar pines filtrados

    this.mostrarPines(filtro);
  }
}
