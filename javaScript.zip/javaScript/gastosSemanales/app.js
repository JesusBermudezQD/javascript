//Variables
const presupuestoUsuario = prompt("¿Cual es su presupuesto semanal?");
const formulario = document.getElementById("form");
let cantidadPresupuesto;

//Clases
//Clase presupuesto
class Presupuesto {
  constructor(presupuesto) {
    this.presupuesto = Number(presupuesto);
    this.restante = Number(presupuesto);
  }

  //metodo para ir restando
  presupuestoRestante(cantidad = 0) {
    return (this.restante -= Number(cantidad));
  }
}

//Clase interfaz se maneja todo lo referente al html

class Interfas {
  insertaPresupuesto(cantidad) {
    const presupuestoSpan = document.getElementById("total");
    const restanteSpan = document.getElementById("restante");

    //agregando al html

    presupuestoSpan.innerHTML = `${cantidad}`;
    restanteSpan.innerHTML = `${cantidad}`;
  }
  mostrarMensaje(mensaje, tipo) {
    const div = document.createElement("div");
    if (tipo === "error") {
      div.classList.add("mensaje", "text-center", "alert", "alert-danger");
    } else {
      div.classList.add("mensaje", "text-center", "alert", "alert-success");
    }

    div.innerHTML = `${mensaje}`;
    formulario.insertBefore(div, document.querySelector("#tt"));
    setTimeout(function () {
      document.querySelector(".mensaje").remove();
      formulario.reset();
    }, 3000);
  }

  agregarGasto(nombre, cantidad) {
    const gastosListado = document.querySelector("#listado ul");
    //creando li de la lista
    const li = document.createElement("li");
    li.classList.add(
      "list-group-item",
      "d-flex",
      "justify-content-between",
      "align-items-center"
    );
    //insertar gasto
    li.innerHTML = `
                    ${nombre}
                    <span class="badge badge-pill badge-primary"> $ ${cantidad}</span>
                   `;

    //insertando al html
    gastosListado.appendChild(li);
  }

  presupuestoRestante(cantidad) {
    const restanteSpan = document.querySelector("#restante");

    const presupuestoRestanteUsuario = cantidadPresupuesto.presupuestoRestante(
      cantidad
    );

    restanteSpan.innerHTML = `${presupuestoRestanteUsuario}`;
    console.log(presupuestoRestanteUsuario);

    this.verificarRestante();
  }

  verificarRestante() {
    const presupuestoTotal = cantidadPresupuesto.presupuesto;
    const presupuestoRestante = cantidadPresupuesto.restante;
    //comprobando el 25%
    if (presupuestoTotal / 4 > presupuestoRestante) {
      const divRestante = document.querySelector(".restante");
      divRestante.classList.remove("alert-success", "alert-warning");
      divRestante.classList.add("alert", "alert-danger");
    } else if (presupuestoTotal / 2 < presupuestoRestante) {
      const divRestante = document.querySelector(".restante");
      divRestante.classList.remove("alert-success");
      divRestante.classList.add("alert-warning");
    }
  }
}

//Eventlisteners

document.addEventListener("DOMContentLoaded", function () {
  if (presupuestoUsuario === null || presupuestoUsuario === "") {
    window.location.reload();
  } else {
    //agregando presupuesto

    cantidadPresupuesto = new Presupuesto(presupuestoUsuario);

    //instancias la clase interfaz

    const ui = new Interfas();

    ui.insertaPresupuesto(cantidadPresupuesto.presupuesto);
  }
});

formulario.addEventListener("submit", function (e) {
  e.preventDefault();

  //leer datos del formulario

  const nombreGasto = document.querySelector("#gasto").value;
  const precioGasto = document.querySelector("#cantidad").value;

  //instanciando interfaz
  const ui = new Interfas();

  if (nombreGasto === "" || precioGasto === "") {
    //dos parametros un mensaje y un tipo
    ui.mostrarMensaje("Hubo un Error", "error");
  } else {
    ui.mostrarMensaje("Todo bien todo correcto", "bien");

    ui.agregarGasto(nombreGasto, precioGasto);
    ui.presupuestoRestante(precioGasto);
  }
});
